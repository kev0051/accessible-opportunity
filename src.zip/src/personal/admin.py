from django.contrib import admin
#from personal.models import Question

# Register your models here.

# new table created to display in admin console
#admin.site.register(Question)